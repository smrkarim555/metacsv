let files = [];
let metadataList = [];
let imageMap = {};

function storeFiles(fileList) {
  files = Array.from(fileList);
  imageMap = {};
  let loaded = 0;

  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = e => {
      imageMap[file.name] = e.target.result;
      loaded++;
    };
    reader.readAsDataURL(file);
  });
}

function saveApiKey() {
  const key = document.getElementById("apiKeyInput").value;
  fetch("/set_api_key", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ key })
  }).then(() => {
    document.getElementById("apiSaved").classList.remove("hidden");
  });
}

function simulateProgress(total, onComplete) {
  const progressText = document.getElementById("progressText");
  let count = 0;

  const interval = setInterval(() => {
    count++;
    progressText.textContent = `${count} / ${total}`;
    if (count >= total) {
      clearInterval(interval);
      onComplete();
    }
  }, 400);
}

function generateMetadata() {
  if (!files.length) {
    alert("Please upload images first.");
    return;
  }

  const lang = document.getElementById("langSelect").value;
  const filenames = files.map(f => f.name);

  document.getElementById("loading").classList.remove("hidden");
document.getElementById("successCheck").style.display = "none";
document.getElementById("generatingText").style.display = "inline";
document.getElementById("loadingSpinner").style.display = "block";
  document.getElementById("loadingSpinner").style.display = "block";
  document.getElementById("successCheck").classList.add("hidden");
  document.getElementById("progressText").textContent = `0 / ${filenames.length}`;

  simulateProgress(filenames.length, () => {
    fetch("/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filenames, language: lang })
    })
      .then(res => res.json())
      .then(data => {
        metadataList = data;
        const table = document.getElementById("previewTable");
        table.innerHTML = "<tr><th>Preview</th><th>Filename</th><th>Title</th><th>Description</th><th>Keywords</th></tr>";
        data.forEach((d, i) => {
          const imgSrc = imageMap[d.filename] || '';
          const imgTag = imgSrc ? `<img src="${imgSrc}" alt="preview" width="120">` : '';
          table.innerHTML += `<tr>
            <td>${imgTag}</td>
            <td>${d.filename}</td>
            <td>${d.title}</td>
            <td>${d.description}</td>
            <td>${d.keywords}</td>
          </tr>`;
        });

        document.getElementById("loading").classList.add("hidden");
        document.getElementById("loadingSpinner").style.display = "none";
        document.getElementById("successCheck").style.display = "inline";
document.getElementById("generatingText").style.display = "none";
document.getElementById("loadingSpinner").style.display = "none";
      });
  });
}

function downloadSelectedCSVs() {
  const selectedPlatforms = Array.from(document.querySelectorAll(".platform input:checked")).map(input => input.value);

  if (!metadataList.length || selectedPlatforms.length === 0) {
    alert("Generate metadata and select at least one platform.");
    return;
  }

  selectedPlatforms.forEach(platform => {
    let csv = "Filename,Title,Description,Keywords\n";
    metadataList.forEach(d => {
      csv += `"${d.filename}","${d.title}","${d.description}","${d.keywords}"\n`;
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = platform + "_metadata.csv";
    link.click();
  });
}
